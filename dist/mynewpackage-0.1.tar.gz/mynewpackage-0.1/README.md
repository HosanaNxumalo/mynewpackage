# mynewpackage

mynewpackage is a Python library for dealing with numerical functions.

## Installation

Use the package manager [pip](https://github.com/HosanaNxumalo/mynewpackage.git) to install mynewpackage.

```bash
pip install git+https://github.com/HosanaNxumalo/mynewpackage.git
```

## Usage

```python
import mynewpackage

```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
